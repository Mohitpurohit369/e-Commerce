const config = {
    secret_jwt :'thisismysecretkey',
    emailUser:'',
    password:''
}
module.exports =config;